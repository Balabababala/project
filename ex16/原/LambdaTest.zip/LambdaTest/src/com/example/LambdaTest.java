package com.example;

public class LambdaTest {

    public static void main(String[] args) {
        String[] strList01 = {"tomorrow", "toto", "to", "timbukto", "the", "hello", "heat"};

        AnalyzerTool stringTool = new AnalyzerTool();
        String searchStr = "to";

        System.out.println("Searching for: " + searchStr);

        System.out.println("==Contains==");
        // Your code here

        System.out.println("==Starts With==");
        // Your code here

        System.out.println("==Equals==");
        // Your code here

        System.out.println("==Ends With==");
        // Your code here

        System.out.println("==Less than 5==");
        // Your Code here

        System.out.println("==Greater than 5==");
        // Your code here
    }
    
}
